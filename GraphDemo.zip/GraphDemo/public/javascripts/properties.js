module.exports = {
    // IPs for DSE
    ip: function () {
        return "127.0.0.1";
    },
    // Graph table name
    graphName: function () {
        return "GraphDemo";
    },
    // Graph Query
    graphQuery: function () {
        return "g.V().outE().subgraph('x').cap('x')";
    }
}