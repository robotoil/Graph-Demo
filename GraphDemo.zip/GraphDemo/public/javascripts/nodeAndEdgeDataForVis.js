var nodes = [
{id: 5681111040, label: 'Sales'},
{id: 5681111041, label: 'Prospects'},
{id: 5681111042, label: 'DataStax'},
{id: 5681111043, label: 'Marketing'},
{id: 5681111044, label: 'Human Resources'},
{id: 5681111045, label: 'Partners'},
{id: 5681111046, label: 'Accounts'}
];

var edges=[
{from: 5681111040, to: 5681111045},
{from: 5681111042, to: 5681111044},
{from: 5681111040, to: 5681111046},
{from: 5681111042, to: 5681111043},
{from: 5681111040, to: 5681111041},
{from: 5681111042, to: 5681111040}]
;