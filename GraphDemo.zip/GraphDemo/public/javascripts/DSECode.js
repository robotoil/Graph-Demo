const dse = require('dse-driver');
const dseGraph = require('dse-graph');

// include DSE code to connect and process the graph query.
const DSECode = require('./properties');

console.log("Connecting to DataStax: " + DSECode.ip());
console.log("Using graph: "+DSECode.graphName());

// Connection to DSE.
const client = new dse.Client({
    contactPoints: [DSECode.ip()],
    profiles: [
        new dse.ExecutionProfile('default', {
            graphOptions: {name: DSECode.graphName()}
        })
    ]
});
const g = dseGraph.traversalSource(client);

// Submit query to DSE
console.log("Issuing graph query: " + DSECode.graphQuery());
const result = client.executeGraph(DSECode.graphQuery(), function (err, result) {
    if (err) {
        console.log(err);
        process.exit(-1);
    }

    //console.log(result);
    const v1 = result.toArray();
    console.log("Result array")
    console.log(v1);
    console.log('Results Returned = ' + v1.length);

    //   console.log('----------- extracted values for testing  ------------------------------------');
    //
    //    for (i = 0; i < v1[0].vertices.length; i++) {
    //
    //       console.log(" ");
    //      console.log("Verticies property type: " + v1[0].vertices[i].type);
    //        console.log("Verticies property member_id: " + v1[0].vertices[i].properties.name[0].id["~out_vertex"].member_id);
    //        console.log("Verticies property community_id: " + v1[0].vertices[i].properties.name[0].id["~out_vertex"].community_id);
    //        console.log("Verticies property name: " + v1[0].vertices[i].properties.name[0].value);
    //    }
    //    for (i = 0; i < v1[0].edges.length; i++) {
    //        console.log(" ");
    //        console.log("Edges property type: " + v1[0].edges[i].type);
    //        console.log("Edges property label: " + v1[0].edges[i].label);
    //        console.log("Edges property out member_id: " + v1[0].edges[i].id["~out_vertex"].member_id);
    //        console.log("Edges property out community_id: " + v1[0].edges[i].id["~out_vertex"].community_id);
    //        console.log("Edges property in member_id: " + v1[0].edges[i].id["~in_vertex"].member_id);
    //        console.log("Edges property in community_id: " + v1[0].edges[0].id["~in_vertex"].community_id);
    //    }

    var nodes = '[\n';
    var edges = '[\n';
    var nodesArray = [];

    // Do vertices
    for (i = 0; i < v1[0].vertices.length; i++) {
        // Build array for both in and out.
        var nodeID = v1[0].vertices[i].properties.name[0].id["~out_vertex"].community_id.toString() + v1[0].vertices[i].properties.name[0].id["~out_vertex"].member_id.toString();

        nodesArray.push([nodeID, v1[0].vertices[i].properties.name[0].value]);
    }

    // Do edges
    for (i = 0; i < v1[0].edges.length; i++) {

        var idConcatOut = v1[0].edges[i].id["~out_vertex"].community_id.toString() + v1[0].edges[i].id["~out_vertex"].member_id.toString();
        var idConcatIn = v1[0].edges[i].id["~in_vertex"].community_id.toString() + v1[0].edges[i].id["~in_vertex"].member_id.toString();

        edges = edges +
            '{from: ' + idConcatOut + ', to: ' + idConcatIn + '}';
        if (i < v1[0].edges.length - 1) {
            edges = edges + ',\n';
        }
    }

    // Edge end of JSON.
    edges = edges + ']\n';

    // Sort Nodes
    var nodesSortArray = nodesArray.sort();

    // Eliminate duplicates in node array.
    function dedup(arr) {
        var hashTable = {};

        return arr.filter(function (el) {
            var key = JSON.stringify(el);
            var match = Boolean(hashTable[key]);

            return (match ? false : hashTable[key] = true);
        });
    }

    var uniqueNodes = dedup(nodesSortArray);

    // Rebuild Nodes for vis. This piece of code is able to handle future use cases where JSON stuctures differ
    for (i = 0; i < uniqueNodes.length; i++) {
        //console.log(uniqueNodes[i]);
        var x = uniqueNodes[i];
        var array_id = x[0];
        var array_label = x[1];

        nodes = nodes +
            '{id: ' + array_id + ', label: \'' + array_label + '\'}';

        if (i < uniqueNodes.length - 1) {
            nodes = nodes + ',\n';
        }
        if (i === uniqueNodes.length - 1) {
            nodes = nodes + '\n]';
        }
    }
    // Account for 0 nodes returned
    if (uniqueNodes.length === 0) {
        nodes = nodes + '\n]';
    }
    // This is the parsed result.
    console.log('nodes=\n' + nodes);
    console.log(" ");
    console.log('edges=\n' + edges);

    // Write the new data js file.
    console.log("Write nodes and edges data to file: nodeAndEdgeDataForVis.js");

    // This is where the node and edge data get written to file. The 2 newlines are formatting in the file.
    var fs = require('fs');
    fs.writeFile("./public/javascripts/nodeAndEdgeDataForVis.js", "var nodes = " + nodes + ";\n\n" +
        "var edges=" + edges + ";", function (err) {
        if (err) {
            return console.log(err);
        }
    });
});